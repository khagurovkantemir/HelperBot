#!/bin/bash
# HelperBot Build Script for Android Studio

echo "🔨 HelperBot Android Build"
echo "=========================="
echo ""
echo "ШАГ 1: Открой Android Studio"
echo "ШАГ 2: File → Open → выбери папку HelperBot"
echo "ШАГ 3: Жди синхронизации Gradle"
echo "ШАГ 4: Build → Build Bundle(s) / APK(s) → Build APK(s)"
echo ""
echo "Или в терминале:"
echo "cd HelperBot"
echo "./gradlew assembleRelease"
echo ""
echo "APK будет в: app/build/outputs/apk/release/app-release.apk"
