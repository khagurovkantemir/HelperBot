# Keep Room Database
-keep class com.nolaini.helperbot.data.** { *; }
-keep interface com.nolaini.helperbot.data.** { *; }

# Keep TensorFlow Lite
-keep class org.tensorflow.lite.** { *; }

# Keep Gson
-keep class com.google.gson.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Keep Coroutines
-keep class kotlinx.coroutines.** { *; }

# Keep ViewModel
-keep class androidx.lifecycle.** { *; }
-keepclasseswithmembers class * {
    @androidx.lifecycle.OnLifecycleEvent <methods>;
}

# Keep Compose
-keep class androidx.compose.** { *; }
-keep interface androidx.compose.** { *; }

# Keep App classes
-keep class com.nolaini.helperbot.** { *; }

# Remove logging
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
