package com.nolaini.helperbot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nolaini.helperbot.data.ScheduleLesson
import com.nolaini.helperbot.ui.viewmodel.MainViewModel

@Composable
fun ScheduleScreen(viewModel: MainViewModel) {
    val schedule by viewModel.schedule.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "📅 Расписание",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            FloatingActionButton(
                onClick = { showDialog = true },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add lesson")
            }
        }

        if (schedule.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📚 Добавь свои уроки", fontSize = 18.sp)
                    Text("Нажми + чтобы начать", fontSize = 14.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(schedule) { lesson ->
                    LessonCard(lesson, viewModel)
                }
            }
        }
    }

    if (showDialog) {
        AddLessonDialog(viewModel) { showDialog = false }
    }
}

@Composable
fun LessonCard(lesson: ScheduleLesson, viewModel: MainViewModel) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { }
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Урок ${lesson.lessonNumber}", fontWeight = FontWeight.Bold)
                Text("${lesson.startTime} - ${lesson.endTime}", fontSize = 12.sp)
            }
            Button(
                onClick = { viewModel.deleteLesson(lesson) },
                modifier = Modifier.height(36.dp)
            ) {
                Text("Удалить")
            }
        }
    }
}

@Composable
fun AddLessonDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    var lessonNumber by remember { mutableStateOf("1") }
    var startTime by remember { mutableStateOf("08:00") }
    var endTime by remember { mutableStateOf("08:45") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить урок") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = lessonNumber,
                    onValueChange = { lessonNumber = it },
                    label = { Text("Номер урока") }
                )
                OutlinedTextField(
                    value = startTime,
                    onValueChange = { startTime = it },
                    label = { Text("Начало (HH:mm)") }
                )
                OutlinedTextField(
                    value = endTime,
                    onValueChange = { endTime = it },
                    label = { Text("Конец (HH:mm)") }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.addLesson(
                        ScheduleLesson(
                            lessonNumber = lessonNumber.toIntOrNull() ?: 1,
                            startTime = startTime,
                            endTime = endTime
                        )
                    )
                    onDismiss()
                }
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}
