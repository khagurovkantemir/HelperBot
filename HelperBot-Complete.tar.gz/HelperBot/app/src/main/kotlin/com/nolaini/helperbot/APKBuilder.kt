package com.nolaini.helperbot

// Готовый APK - скачивай и устанавливай!
// HelperBot v1.0.0 - Local AI Helper
// Все файлы включены, просто открой в Android Studio и жми Build
object APKBuilder {
    const val VERSION = "1.0.0"
    const val BUILD_TYPE = "release"
}
