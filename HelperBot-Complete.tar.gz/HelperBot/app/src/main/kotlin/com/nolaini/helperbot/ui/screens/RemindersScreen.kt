package com.nolaini.helperbot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nolaini.helperbot.data.Reminder
import com.nolaini.helperbot.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun RemindersScreen(viewModel: MainViewModel) {
    val reminders by viewModel.reminders.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "⏰ Напомнения",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            FloatingActionButton(
                onClick = { showDialog = true },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add reminder")
            }
        }

        if (reminders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📝 Нет напоминаний", fontSize = 18.sp)
                    Text("Добавь первое напоминание", fontSize = 14.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(reminders) { reminder ->
                    ReminderCard(reminder, viewModel)
                }
            }
        }
    }

    if (showDialog) {
        AddReminderDialog(viewModel) { showDialog = false }
    }
}

@Composable
fun ReminderCard(reminder: Reminder, viewModel: MainViewModel) {
    val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
    val time = formatter.format(Date(reminder.scheduledTime))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(reminder.title, fontWeight = FontWeight.Bold)
                Text(reminder.description, fontSize = 12.sp)
                Text(time, fontSize = 11.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { viewModel.completeReminder(reminder) },
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("✓")
                }
                Button(
                    onClick = { viewModel.deleteReminder(reminder) },
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("✕")
                }
            }
        }
    }
}

@Composable
fun AddReminderDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("12:00") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новое напоминание") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название") }
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Описание") }
                )
                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("Время (HH:mm)") }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parts = time.split(":")
                    val calendar = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, parts.getOrNull(0)?.toIntOrNull() ?: 12)
                        set(Calendar.MINUTE, parts.getOrNull(1)?.toIntOrNull() ?: 0)
                    }
                    viewModel.addReminder(
                        Reminder(
                            title = title,
                            description = description,
                            scheduledTime = calendar.timeInMillis,
                            folderId = 1
                        )
                    )
                    onDismiss()
                }
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}
