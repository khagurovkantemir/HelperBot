package com.nolaini.helperbot.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder

class LocalAIEngine(private val context: Context) {
    private var interpreter: Interpreter? = null
    private val modelName = "helperbot_model.tflite"

    init {
        loadModel()
    }

    private fun loadModel() {
        try {
            val modelBuffer = FileUtil.loadMappedFile(context, modelName)
            interpreter = Interpreter(modelBuffer)
        } catch (e: Exception) {
            // Fallback: use heuristic responses if model fails
            e.printStackTrace()
        }
    }

    suspend fun generateResponse(input: String, context: String = ""): String {
        return withContext(Dispatchers.Default) {
            try {
                if (interpreter == null) {
                    return@withContext generateHeuristicResponse(input, context)
                }

                // Prepare input
                val inputBuffer = prepareInput(input)
                
                // Run inference
                val output = ByteBuffer.allocateDirect(4 * 256)
                    .order(ByteOrder.nativeOrder())
                
                interpreter?.run(arrayOf(inputBuffer), mapOf(0 to output))
                
                // Parse output
                parseOutput(output, input, context)
            } catch (e: Exception) {
                generateHeuristicResponse(input, context)
            }
        }
    }

    private fun prepareInput(text: String): ByteBuffer {
        val maxLength = 512
        val buffer = ByteBuffer.allocateDirect(maxLength * 4)
            .order(ByteOrder.nativeOrder())
        
        val tokens = text.split(" ").take(maxLength)
        for (token in tokens) {
            buffer.putInt(token.hashCode())
        }
        
        return buffer
    }

    private fun parseOutput(output: ByteBuffer, input: String, context: String): String {
        output.rewind()
        val response = StringBuilder()
        
        for (i in 0 until 256) {
            val score = output.float
            if (score > 0.1f) {
                response.append("${getTokenFromIndex(i)} ")
            }
        }
        
        return if (response.isNotEmpty()) {
            response.toString().trim()
        } else {
            generateHeuristicResponse(input, context)
        }
    }

    private fun getTokenFromIndex(index: Int): String {
        return when (index) {
            1 -> "Удачного урока!"
            2 -> "Концентрируйся на учёбе"
            3 -> "Ты справишься"
            4 -> "Хорошего отдыха"
            5 -> "Отдохни немного"
            6 -> "Пора заканчивать учёбу"
            7 -> "Отличный день позади!"
            else -> ""
        }
    }

    private fun generateHeuristicResponse(input: String, context: String): String {
        return when {
            input.contains("урок", ignoreCase = true) && input.contains("начало", ignoreCase = true) -> 
                "Удачного урока! 📚 Ты можешь это сделать!"
            input.contains("перемена", ignoreCase = true) || input.contains("отдых", ignoreCase = true) -> 
                "Хорошего отдыха! 😊 Восстанови силы!"
            input.contains("конец", ignoreCase = true) && input.contains("день", ignoreCase = true) -> 
                "Отличный день позади! 🌟 Отдохни хорошо!"
            input.contains("помощь", ignoreCase = true) || input.contains("помоги", ignoreCase = true) -> 
                "Я помогу с домашним заданием. Что нужно?"
            input.contains("время", ignoreCase = true) -> 
                "Время идёт. Сосредоточься! ⏰"
            else -> 
                "Я здесь, чтобы помочь! Что нужно?"
        }
    }

    fun destroy() {
        interpreter?.close()
        interpreter = null
    }
}
