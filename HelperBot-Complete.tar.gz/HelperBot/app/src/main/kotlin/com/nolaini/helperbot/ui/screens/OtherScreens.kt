package com.nolaini.helperbot.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nolaini.helperbot.data.AgentScenario
import com.nolaini.helperbot.data.AppSettings
import com.nolaini.helperbot.ui.viewmodel.MainViewModel

// Agent Screen
@Composable
fun AgentScreen(viewModel: MainViewModel) {
    val scenarios by viewModel.scenarios.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "🤖 Сценарии Агента",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            FloatingActionButton(
                onClick = { showDialog = true },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add scenario")
            }
        }

        if (scenarios.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📋 Создай сценарий", fontSize = 18.sp)
                    Text("Например: 19:30 - напоминание о ДЗ", fontSize = 14.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(scenarios) { scenario ->
                    ScenarioCard(scenario, viewModel)
                }
            }
        }
    }

    if (showDialog) {
        AddScenarioDialog(viewModel) { showDialog = false }
    }
}

@Composable
fun ScenarioCard(scenario: AgentScenario, viewModel: MainViewModel) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(scenario.name, fontWeight = FontWeight.Bold)
                Text(scenario.triggerTime, fontSize = 12.sp)
                Text(scenario.description, fontSize = 11.sp)
            }
            Switch(
                checked = scenario.isActive,
                onCheckedChange = { viewModel.toggleScenario(scenario) }
            )
        }
    }
}

@Composable
fun AddScenarioDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var triggerTime by remember { mutableStateOf("19:30") }
    var description by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый сценарий") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название") }
                )
                OutlinedTextField(
                    value = triggerTime,
                    onValueChange = { triggerTime = it },
                    label = { Text("Время (HH:mm)") }
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Описание") }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.addScenario(
                        AgentScenario(
                            name = name,
                            triggerTime = triggerTime,
                            description = description,
                            actions = "[]"
                        )
                    )
                    onDismiss()
                }
            ) {
                Text("Создать")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

// Settings Screen
@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val settings by viewModel.settings.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "⚙️ Настройки",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        settings?.let { currentSettings ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ИИ Режим", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Только локальная ИИ")
                        Switch(
                            checked = currentSettings.useLocalAIOnly,
                            onCheckedChange = {
                                viewModel.updateSettings(
                                    currentSettings.copy(useLocalAIOnly = it)
                                )
                            }
                        )
                    }
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Уведомления", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Пуши включены")
                        Switch(
                            checked = currentSettings.enablePushes,
                            onCheckedChange = {
                                viewModel.updateSettings(
                                    currentSettings.copy(enablePushes = it)
                                )
                            }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("AOD Таймер")
                        Switch(
                            checked = currentSettings.enableAODTimer,
                            onCheckedChange = {
                                viewModel.updateSettings(
                                    currentSettings.copy(enableAODTimer = it)
                                )
                            }
                        )
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("О приложении", fontWeight = FontWeight.Bold)
                    Text("HelperBot v1.0.0", fontSize = 12.sp)
                    Text("Локальная ИИ | Без интернета", fontSize = 12.sp)
                }
            }
        }
    }
}
