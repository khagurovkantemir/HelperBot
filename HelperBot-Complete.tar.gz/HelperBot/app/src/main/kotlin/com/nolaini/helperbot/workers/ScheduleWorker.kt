package com.nolaini.helperbot.workers

import android.content.Context
import androidx.work.*
import com.nolaini.helperbot.HelperBotApp
import com.nolaini.helperbot.notifications.NotificationService
import java.util.concurrent.TimeUnit

class ScheduleWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val notificationService = NotificationService(applicationContext)
            val db = HelperBotApp.database
            
            // Check scheduled lessons
            val schedule = db.scheduleDao().getAllLessons()
            for (lesson in schedule) {
                notificationService.sendLessonNotification(
                    lesson.lessonNumber,
                    "Удачного урока! 📚 Ты можешь это сделать!"
                )
            }

            // Check reminders
            val reminders = db.reminderDao().getActiveReminders()
            for (reminder in reminders) {
                notificationService.sendReminderNotification(
                    reminder.id,
                    reminder.title,
                    reminder.description
                )
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }

    companion object {
        fun schedulePeriodicCheck(context: Context) {
            val scheduleWork = PeriodicWorkRequestBuilder<ScheduleWorker>(
                15, TimeUnit.MINUTES
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "schedule_check",
                ExistingPeriodicWorkPolicy.KEEP,
                scheduleWork
            )
        }
    }
}
