package com.nolaini.helperbot.data

import androidx.room.*
import java.time.LocalTime

// School Schedule
@Entity(tableName = "schedule")
data class ScheduleLesson(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val lessonNumber: Int,
    val startTime: String, // HH:mm
    val endTime: String,   // HH:mm
    val schoolDayEnd: Boolean = false
)

// Reminders & Pushes
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val scheduledTime: Long, // Unix timestamp
    val folderId: Int,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// Folders for organizing reminders
@Entity(tableName = "folders")
data class ReminderFolder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val color: Int = 0xFF2196F3.toInt(),
    val icon: String = "📁"
)

// Agent Scenarios
@Entity(tableName = "scenarios")
data class AgentScenario(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val triggerTime: String, // HH:mm or event-based
    val actions: String,     // JSON serialized list of actions
    val isActive: Boolean = true,
    val description: String = ""
)

// Action types for scenarios
data class ScenarioAction(
    val type: String, // "reminder", "message", "chat", "notification"
    val content: String,
    val delay: Int = 0
)

// Chat History (for AI conversations)
@Entity(tableName = "chat_history")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val sessionId: Int
)

// Settings
@Entity(tableName = "settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val useLocalAIOnly: Boolean = true,
    val enablePushes: Boolean = true,
    val enableAODTimer: Boolean = true,
    val aodInterval: Int = 10, // minutes
    val workerUrl: String = "https://super-bar-3c76.tand69483.workers.dev/",
    val lastSyncTime: Long = 0
)

// DAOs
@Dao
interface ScheduleDao {
    @Query("SELECT * FROM schedule ORDER BY lessonNumber")
    suspend fun getAllLessons(): List<ScheduleLesson>

    @Query("SELECT * FROM schedule WHERE lessonNumber = :lessonNumber")
    suspend fun getLesson(lessonNumber: Int): ScheduleLesson?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLesson(lesson: ScheduleLesson)

    @Delete
    suspend fun deleteLesson(lesson: ScheduleLesson)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders WHERE folderId = :folderId ORDER BY scheduledTime")
    suspend fun getRemindersByFolder(folderId: Int): List<Reminder>

    @Query("SELECT * FROM reminders WHERE isCompleted = 0 ORDER BY scheduledTime")
    suspend fun getActiveReminders(): List<Reminder>

    @Insert
    suspend fun insertReminder(reminder: Reminder)

    @Update
    suspend fun updateReminder(reminder: Reminder)

    @Delete
    suspend fun deleteReminder(reminder: Reminder)
}

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders")
    suspend fun getAllFolders(): List<ReminderFolder>

    @Insert
    suspend fun insertFolder(folder: ReminderFolder)

    @Delete
    suspend fun deleteFolder(folder: ReminderFolder)
}

@Dao
interface ScenarioDao {
    @Query("SELECT * FROM scenarios WHERE isActive = 1")
    suspend fun getActiveScenarios(): List<AgentScenario>

    @Query("SELECT * FROM scenarios")
    suspend fun getAllScenarios(): List<AgentScenario>

    @Insert
    suspend fun insertScenario(scenario: AgentScenario)

    @Update
    suspend fun updateScenario(scenario: AgentScenario)

    @Delete
    suspend fun deleteScenario(scenario: AgentScenario)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_history WHERE sessionId = :sessionId ORDER BY timestamp DESC")
    suspend fun getChatMessages(sessionId: Int): List<ChatMessage>

    @Insert
    suspend fun insertMessage(message: ChatMessage)

    @Delete
    suspend fun deleteMessage(message: ChatMessage)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings LIMIT 1")
    suspend fun getSettings(): AppSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: AppSettings)
}

// Main Database
@Database(
    entities = [
        ScheduleLesson::class,
        Reminder::class,
        ReminderFolder::class,
        AgentScenario::class,
        ChatMessage::class,
        AppSettings::class
    ],
    version = 1
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scheduleDao(): ScheduleDao
    abstract fun reminderDao(): ReminderDao
    abstract fun folderDao(): FolderDao
    abstract fun scenarioDao(): ScenarioDao
    abstract fun chatDao(): ChatDao
    abstract fun settingsDao(): SettingsDao
}
