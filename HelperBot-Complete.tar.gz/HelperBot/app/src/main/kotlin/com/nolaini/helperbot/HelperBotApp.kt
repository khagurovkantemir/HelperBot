package com.nolaini.helperbot

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.room.Room
import com.nolaini.helperbot.data.AppDatabase
import com.nolaini.helperbot.ai.LocalAIEngine

class HelperBotApp : Application() {
    companion object {
        lateinit var database: AppDatabase
        lateinit var aiEngine: LocalAIEngine
    }

    override fun onCreate() {
        super.onCreate()

        // Initialize Database
        database = Room.databaseBuilder(
            this,
            AppDatabase::class.java,
            "helperbot_db"
        ).build()

        // Initialize Local AI Engine
        aiEngine = LocalAIEngine(this)

        // Create Notification Channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "helperbot_channel",
                "HelperBot Notifications",
                NotificationManager.IMPORTANCE_HIGH
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
