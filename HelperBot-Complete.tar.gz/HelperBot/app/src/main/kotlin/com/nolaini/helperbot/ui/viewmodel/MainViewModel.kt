package com.nolaini.helperbot.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nolaini.helperbot.HelperBotApp
import com.nolaini.helperbot.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = HelperBotApp.database
    private val aiEngine = HelperBotApp.aiEngine

    // Schedule
    private val _schedule = MutableStateFlow<List<ScheduleLesson>>(emptyList())
    val schedule: StateFlow<List<ScheduleLesson>> = _schedule

    // Reminders
    private val _reminders = MutableStateFlow<List<Reminder>>(emptyList())
    val reminders: StateFlow<List<Reminder>> = _reminders

    private val _folders = MutableStateFlow<List<ReminderFolder>>(emptyList())
    val folders: StateFlow<List<ReminderFolder>> = _folders

    // Scenarios
    private val _scenarios = MutableStateFlow<List<AgentScenario>>(emptyList())
    val scenarios: StateFlow<List<AgentScenario>> = _scenarios

    // Chat
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages

    // Settings
    private val _settings = MutableStateFlow<AppSettings?>(null)
    val settings: StateFlow<AppSettings?> = _settings

    init {
        loadData()
        initializeDefaults()
    }

    private fun loadData() {
        viewModelScope.launch {
            _schedule.value = db.scheduleDao().getAllLessons()
            _reminders.value = db.reminderDao().getActiveReminders()
            _folders.value = db.folderDao().getAllFolders()
            _scenarios.value = db.scenarioDao().getActiveScenarios()
            _settings.value = db.settingsDao().getSettings() ?: AppSettings()
        }
    }

    private fun initializeDefaults() {
        viewModelScope.launch {
            val existing = db.settingsDao().getSettings()
            if (existing == null) {
                val defaultSettings = AppSettings()
                db.settingsDao().saveSettings(defaultSettings)
                _settings.value = defaultSettings
            }
        }
    }

    // Schedule operations
    fun addLesson(lesson: ScheduleLesson) {
        viewModelScope.launch {
            db.scheduleDao().insertLesson(lesson)
            loadData()
        }
    }

    fun deleteLesson(lesson: ScheduleLesson) {
        viewModelScope.launch {
            db.scheduleDao().deleteLesson(lesson)
            loadData()
        }
    }

    // Reminder operations
    fun addReminder(reminder: Reminder) {
        viewModelScope.launch {
            db.reminderDao().insertReminder(reminder)
            loadData()
        }
    }

    fun completeReminder(reminder: Reminder) {
        viewModelScope.launch {
            db.reminderDao().updateReminder(reminder.copy(isCompleted = true))
            loadData()
        }
    }

    fun deleteReminder(reminder: Reminder) {
        viewModelScope.launch {
            db.reminderDao().deleteReminder(reminder)
            loadData()
        }
    }

    // Folder operations
    fun addFolder(folder: ReminderFolder) {
        viewModelScope.launch {
            db.folderDao().insertFolder(folder)
            loadData()
        }
    }

    // Scenario operations
    fun addScenario(scenario: AgentScenario) {
        viewModelScope.launch {
            db.scenarioDao().insertScenario(scenario)
            loadData()
        }
    }

    fun toggleScenario(scenario: AgentScenario) {
        viewModelScope.launch {
            db.scenarioDao().updateScenario(scenario.copy(isActive = !scenario.isActive))
            loadData()
        }
    }

    // Chat operations
    fun sendChatMessage(message: String, sessionId: Int = 1) {
        viewModelScope.launch {
            // Add user message
            val userMsg = ChatMessage(
                role = "user",
                content = message,
                sessionId = sessionId
            )
            db.chatDao().insertMessage(userMsg)

            // Generate AI response
            val response = aiEngine.generateResponse(message)
            val assistantMsg = ChatMessage(
                role = "assistant",
                content = response,
                sessionId = sessionId
            )
            db.chatDao().insertMessage(assistantMsg)
            
            loadData()
        }
    }

    // Settings operations
    fun updateSettings(settings: AppSettings) {
        viewModelScope.launch {
            db.settingsDao().saveSettings(settings)
            _settings.value = settings
        }
    }
}
