package com.nolaini.helperbot.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nolaini.helperbot.ui.screens.*
import com.nolaini.helperbot.ui.theme.HelperBotTheme
import com.nolaini.helperbot.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HelperBotTheme {
                HelperBotApp()
            }
        }
    }
}

@Composable
fun HelperBotApp() {
    val viewModel: MainViewModel = viewModel()
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Text("📅") },
                    label = { Text("Расписание") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Text("⏰") },
                    label = { Text("Напомнения") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Text("🤖") },
                    label = { Text("Агент") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Text("💬") },
                    label = { Text("Чат") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Text("⚙️") },
                    label = { Text("Настройки") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedTab) {
                0 -> ScheduleScreen(viewModel)
                1 -> RemindersScreen(viewModel)
                2 -> AgentScreen(viewModel)
                3 -> ChatScreen(viewModel)
                4 -> SettingsScreen(viewModel)
            }
        }
    }
}
